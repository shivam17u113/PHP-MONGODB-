<?php
require 'vendor/autoload.php';
$client= new  MongoDB\Client;
$company=$client->company;
$company_collection=$company->company_collection;

$d1=$company_collection->updateOne(
    ['name'=>'sharad'],
    ['$set'=>["day" =>10]]
);

var_dump($d1);
?>