<?php

require 'vendor/autoload.php';
$client= new  MongoDB\Client;
$company=$client->company;
$company_collection=$company->company_collection;

// insert single document in collection
$result=$company_collection->insertOne(
    ['name'=> 'shivam'
    ]
);

// insert multiple documtns at the same time
// $result1=$company_collection->insertMany([
//     ['name'=> 'shivam','day'=>1],
//     ['name'=> 'sharad','day'=>2]
// ]);

var_dump($result->getInsertedId());


  ?>
