<?php
require 'vendor/autoload.php';
$client= new  MongoDB\Client;
$company=$client->company;
$company_collection=$company->company_collection;

$d1=$company_collection->find(
    ['name'=>'sharad']
);

var_dump($d1);
?>