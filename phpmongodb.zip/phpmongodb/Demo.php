<?php

require 'vendor/autoload.php';

$client= new MongoDB\Client;
$company= $client->company;


//$result=$company->createCollection('examplephp');
//var_dump($result);

foreach($client->listDatabases() as $c)
{
var_dump($c);
}

?>