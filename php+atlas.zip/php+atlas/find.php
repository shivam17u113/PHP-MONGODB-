
<?php

require 'vendor/autoload.php';



  try {
    $client = new MongoDB\Client(
      'mongodb+srv://user:user@cluster1-7augr.mongodb.net/test?retryWrites=true&w=majority');
        $company=$client->test;
        $company_collection=$company->example1;
        echo 'done';
   
  }
  catch(Exception $e) {
    echo 'Message: ' .$e->getMessage();
  }

  try {
    $d1=$company_collection->find(
        ['name'=>'sharad']
    );
    print_r($d1);
    // foreach($d1 as $key =>$value)
    // {
    //     echo '<div>'.$value.'</div>';
    // }
  

  }
  
  //catch exception
  catch(Exception $e) {
    echo 'Message: from find all ' .$e->getMessage();
  }
  


  ?>






