<?php

require 'vendor/autoload.php';



  try {
    $client = new MongoDB\Client(
      'mongodb+srv://user_name:password@cluster1-7augr.mongodb.net/test?retryWrites=true&w=majority');
        $company=$client->test;
        $company_collection=$company->example1;
        echo 'done';
   
  }
  catch(Exception $e) {
    echo 'Message: ' .$e->getMessage();
  }

  try {
    $d1=$company_collection->insertMany([
      ['name'=> 'shivam','day'=>1],
      ['name'=> 'sharad','day'=>2]
  ]);
    
  print_r($d1);

  }
  
  //catch exception
  catch(Exception $e) {
    echo 'Message: from find all ' .$e->getMessage();
  }
  

// insert single document in collection
// $company_collection->insertOne(
//     ['name'=> 'try'
//     ]
// );

// insert multiple documtns at the same time
// $result1=$company_collection->insertMany([
//     ['name'=> 'shivam','day'=>1],
//     ['name'=> 'sharad','day'=>2]
// ]);




  ?>
